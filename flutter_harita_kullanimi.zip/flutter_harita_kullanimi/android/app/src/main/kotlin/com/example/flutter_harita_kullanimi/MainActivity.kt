package com.example.flutter_harita_kullanimi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
